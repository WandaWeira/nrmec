'use strict';

module.exports = {
  up: async (queryInterface, Sequelize) => {
    // Update Payment model
    await queryInterface.addColumn('payments', 'candidateParticipationId', {
      type: Sequelize.INTEGER,
      allowNull: true,
      references: {
        model: 'CandidateParticipations',
        key: 'id'
      },
      onDelete: 'SET NULL'
    });

    await queryInterface.addColumn('payments', 'subcategory', {
      type: Sequelize.STRING,
      allowNull: true
    });

    await queryInterface.addColumn('payments', 'nestedCategory', {
      type: Sequelize.STRING,
      allowNull: true
    });

    await queryInterface.addColumn('payments', 'positionPath', {
      type: Sequelize.STRING,
      allowNull: true
    });

    // Update Fee model
    // Drop and recreate the table since we're changing the ENUM values significantly
    await queryInterface.dropTable('Fees');

    await queryInterface.createTable('Fees', {
      id: {
        type: Sequelize.INTEGER,
        primaryKey: true,
        autoIncrement: true
      },
      electionType: {
        type: Sequelize.ENUM('INTERNAL_PARTY', 'PRIMARIES'),
        allowNull: false
      },
      level: {
        type: Sequelize.ENUM(
          'VILLAGE_CELL',
          'PARISH_WARD',
          'SUBCOUNTY_DIVISION',
          'CONSTITUENCY_MUNICIPALITY',
          'DISTRICT',
          'NATIONAL'
        ),
        allowNull: false
      },
      subType: {
        type: Sequelize.STRING,
        allowNull: true
      },
      category: {
        type: Sequelize.STRING,
        allowNull: true
      },
      subcategory: {
        type: Sequelize.STRING,
        allowNull: true
      },
      nestedCategory: {
        type: Sequelize.STRING,
        allowNull: true
      },
      position: {
        type: Sequelize.STRING,
        allowNull: true
      },
      positionPath: {
        type: Sequelize.STRING,
        allowNull: true,
        unique: true
      },
      amount: {
        type: Sequelize.DECIMAL(10, 2),
        allowNull: false
      },
      isActive: {
        type: Sequelize.BOOLEAN,
        defaultValue: true
      },
      createdAt: {
        type: Sequelize.DATE,
        allowNull: false
      },
      updatedAt: {
        type: Sequelize.DATE,
        allowNull: false
      }
    });

    // Add indexes
    await queryInterface.addIndex('Fees', {
      fields: ['positionPath'],
      unique: true,
      where: {
        isActive: true
      },
      name: 'unique_active_fee_path'
    });

    await queryInterface.addIndex('Fees', {
      fields: ['electionType', 'level', 'category', 'subcategory', 'nestedCategory', 'position'],
      unique: true,
      where: {
        isActive: true,
        positionPath: null
      },
      name: 'unique_active_fee'
    });
  },

  down: async (queryInterface, Sequelize) => {
    // Rollback changes to Payment model
    await queryInterface.removeColumn('payments', 'candidateParticipationId');
    await queryInterface.removeColumn('payments', 'subcategory');
    await queryInterface.removeColumn('payments', 'nestedCategory');
    await queryInterface.removeColumn('payments', 'positionPath');

    // Rollback changes to Fee model (simplified for brevity)
    await queryInterface.dropTable('Fees');
    await queryInterface.createTable('Fees', {
      id: {
        type: Sequelize.INTEGER,
        primaryKey: true,
        autoIncrement: true
      },
      electionType: {
        type: Sequelize.ENUM(
          'nationalElectionType',
          'districtElectionType',
          'constituencyMunicipalityElectionType',
          'subcountiesDivisionsElectionType',
          'parishwardElectionType',
          'villageCellElectionType'
        ),
        allowNull: false
      },
      subType: {
        type: Sequelize.STRING,
        allowNull: false
      },
      category: {
        type: Sequelize.STRING,
        allowNull: true
      },
      position: {
        type: Sequelize.STRING,
        allowNull: true
      },
      amount: {
        type: Sequelize.DECIMAL(10, 2),
        allowNull: false
      },
      isActive: {
        type: Sequelize.BOOLEAN,
        defaultValue: true
      },
      createdAt: {
        type: Sequelize.DATE,
        allowNull: false
      },
      updatedAt: {
        type: Sequelize.DATE,
        allowNull: false
      }
    });

    await queryInterface.addIndex('Fees', {
      fields: ['electionType', 'subType', 'category', 'position'],
      unique: true,
      where: {
        isActive: true
      },
      name: 'unique_active_fee'
    });
  }
};
