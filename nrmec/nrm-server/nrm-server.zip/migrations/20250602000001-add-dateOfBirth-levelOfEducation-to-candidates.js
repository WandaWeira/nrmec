'use strict';

module.exports = {
  up: async (queryInterface, Sequelize) => {
    await queryInterface.addColumn('Candidates', 'dateOfBirth', {
      type: Sequelize.DATEONLY,
      allowNull: true,
    });

    await queryInterface.addColumn('Candidates', 'levelOfEducation', {
      type: Sequelize.STRING,
      allowNull: true,
    });
  },

  down: async (queryInterface, Sequelize) => {
    await queryInterface.removeColumn('Candidates', 'dateOfBirth');
    await queryInterface.removeColumn('Candidates', 'levelOfEducation');
  }
};
