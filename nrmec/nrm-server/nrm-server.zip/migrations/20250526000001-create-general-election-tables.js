'use strict';

module.exports = {
  up: async (queryInterface, Sequelize) => {
    // Create GeneralElectionOppositionCandidates table
    await queryInterface.createTable('GeneralElectionOppositionCandidates', {
      id: {
        allowNull: false,
        autoIncrement: true,
        primaryKey: true,
        type: Sequelize.INTEGER
      },
      ninNumber: {
        type: Sequelize.STRING,
        allowNull: false,
        unique: true
      },
      firstName: {
        type: Sequelize.STRING,
        allowNull: false
      },
      lastName: {
        type: Sequelize.STRING,
        allowNull: false
      },
      gender: {
        type: Sequelize.STRING,
        allowNull: false
      },
      phoneNumber: {
        type: Sequelize.STRING,
        allowNull: false
      },
      party: {
        type: Sequelize.STRING,
        allowNull: false,
        comment: "Political party the opposition candidate belongs to"
      },
      electionType: {
        type: Sequelize.STRING,
        allowNull: false,
        defaultValue: "GENERAL"
      },
      createdAt: {
        allowNull: false,
        type: Sequelize.DATE
      },
      updatedAt: {
        allowNull: false,
        type: Sequelize.DATE
      }
    });

    // Create GeneralElectionOppositionCandidateParticipations table
    await queryInterface.createTable('GeneralElectionOppositionCandidateParticipations', {
      id: {
        allowNull: false,
        autoIncrement: true,
        primaryKey: true,
        type: Sequelize.INTEGER
      },
      oppositionCandidateId: {
        type: Sequelize.INTEGER,
        allowNull: false,
        references: {
          model: 'GeneralElectionOppositionCandidates',
          key: 'id'
        },
        onUpdate: 'CASCADE',
        onDelete: 'CASCADE'
      },
      nrmCandidateParticipationId: {
        type: Sequelize.INTEGER,
        allowNull: false,
        references: {
          model: 'CandidateParticipations',
          key: 'id'
        },
        onUpdate: 'CASCADE',
        onDelete: 'CASCADE'
      },
      electionType: {
        type: Sequelize.ENUM("GENERAL"),
        allowNull: false,
        defaultValue: "GENERAL"
      },
      level: {
        type: Sequelize.ENUM(
          "VILLAGE_CELL",
          "PARISH_WARD",
          "SUBCOUNTY_DIVISION",
          "CONSTITUENCY_MUNICIPALITY",
          "DISTRICT",
          "NATIONAL"
        ),
        allowNull: false
      },
      positionPath: {
        type: Sequelize.STRING,
        allowNull: false
      },
      category: {
        type: Sequelize.STRING,
        allowNull: true
      },
      subcategory: {
        type: Sequelize.STRING,
        allowNull: true
      },
      position: {
        type: Sequelize.STRING,
        allowNull: false
      },
      regionId: {
        type: Sequelize.INTEGER,
        references: {
          model: 'Regions',
          key: 'id'
        },
        onUpdate: 'CASCADE',
        onDelete: 'SET NULL'
      },
      subregionId: {
        type: Sequelize.INTEGER,
        references: {
          model: 'Subregions',
          key: 'id'
        },
        onUpdate: 'CASCADE',
        onDelete: 'SET NULL'
      },
      districtId: {
        type: Sequelize.INTEGER,
        references: {
          model: 'Districts',
          key: 'id'
        },
        onUpdate: 'CASCADE',
        onDelete: 'SET NULL'
      },
      constituencyMunicipalityId: {
        type: Sequelize.INTEGER,
        references: {
          model: 'ConstituencyMunicipality',
          key: 'id'
        },
        onUpdate: 'CASCADE',
        onDelete: 'SET NULL'
      },
      subcountyDivisionId: {
        type: Sequelize.INTEGER,
        references: {
          model: 'SubcountyDivision',
          key: 'id'
        },
        onUpdate: 'CASCADE',
        onDelete: 'SET NULL'
      },
      parishWardId: {
        type: Sequelize.INTEGER,
        references: {
          model: 'ParishWard',
          key: 'id'
        },
        onUpdate: 'CASCADE',
        onDelete: 'SET NULL'
      },
      villageCellId: {
        type: Sequelize.INTEGER,
        references: {
          model: 'VillageCell',
          key: 'id'
        },
        onUpdate: 'CASCADE',
        onDelete: 'SET NULL'
      },
      year: {
        type: Sequelize.INTEGER,
        allowNull: false
      },
      status: {
        type: Sequelize.STRING,
        defaultValue: "active"
      },
      createdAt: {
        allowNull: false,
        type: Sequelize.DATE
      },
      updatedAt: {
        allowNull: false,
        type: Sequelize.DATE
      }
    });

    // Create GeneralElectionVotes table
    await queryInterface.createTable('GeneralElectionVotes', {
      id: {
        allowNull: false,
        autoIncrement: true,
        primaryKey: true,
        type: Sequelize.INTEGER
      },
      candidateParticipationId: {
        type: Sequelize.INTEGER,
        allowNull: true,
        references: {
          model: 'CandidateParticipations',
          key: 'id'
        },
        onUpdate: 'CASCADE',
        onDelete: 'CASCADE'
      },
      oppositionCandidateParticipationId: {
        type: Sequelize.INTEGER,
        allowNull: true,
        references: {
          model: 'GeneralElectionOppositionCandidateParticipations',
          key: 'id'
        },
        onUpdate: 'CASCADE',
        onDelete: 'CASCADE'
      },
      votes: {
        type: Sequelize.INTEGER,
        allowNull: false,
        defaultValue: 0
      },
      notes: {
        type: Sequelize.TEXT,
        allowNull: true
      },
      recordedBy: {
        type: Sequelize.INTEGER,
        allowNull: true,
        references: {
          model: 'Users',
          key: 'id'
        }
      },
      updatedBy: {
        type: Sequelize.INTEGER,
        allowNull: true,
        references: {
          model: 'Users',
          key: 'id'
        }
      },
      createdAt: {
        allowNull: false,
        type: Sequelize.DATE
      },
      updatedAt: {
        allowNull: false,
        type: Sequelize.DATE
      }
    });
  },

  down: async (queryInterface, Sequelize) => {
    await queryInterface.dropTable('GeneralElectionVotes');
    await queryInterface.dropTable('GeneralElectionOppositionCandidateParticipations');
    await queryInterface.dropTable('GeneralElectionOppositionCandidates');
  }
};
