'use strict';

module.exports = {
  up: async (queryInterface, Sequelize) => {
    try {
      // Check if the table exists
      const tableInfo = await queryInterface.describeTable('CandidateParticipations');
      
      // Add columns if they don't exist
      if (!tableInfo.isNominated) {
        await queryInterface.addColumn('CandidateParticipations', 'isNominated', {
          type: Sequelize.BOOLEAN,
          allowNull: false,
          defaultValue: false
        });
      }
      
      if (!tableInfo.nominationNotes) {
        await queryInterface.addColumn('CandidateParticipations', 'nominationNotes', {
          type: Sequelize.TEXT,
          allowNull: true
        });
      }
      
      if (!tableInfo.reasonForNomination) {
        await queryInterface.addColumn('CandidateParticipations', 'reasonForNomination', {
          type: Sequelize.TEXT,
          allowNull: true
        });
      }
      
      if (!tableInfo.nominatedBy) {
        await queryInterface.addColumn('CandidateParticipations', 'nominatedBy', {
          type: Sequelize.INTEGER,
          allowNull: true,
          references: {
            model: 'Users',
            key: 'id'
          }
        });
      }
      
      if (!tableInfo.nominatedAt) {
        await queryInterface.addColumn('CandidateParticipations', 'nominatedAt', {
          type: Sequelize.DATE,
          allowNull: true
        });
      }
      
      console.log('Migration completed successfully');
    } catch (error) {
      console.error('Migration failed:', error.message);
      throw error;
    }
  },

  down: async (queryInterface, Sequelize) => {
    try {
      // Check if the table exists
      const tableInfo = await queryInterface.describeTable('CandidateParticipations');
      
      // Remove columns if they exist
      if (tableInfo.isNominated) {
        await queryInterface.removeColumn('CandidateParticipations', 'isNominated');
      }
      
      if (tableInfo.nominationNotes) {
        await queryInterface.removeColumn('CandidateParticipations', 'nominationNotes');
      }
      
      if (tableInfo.reasonForNomination) {
        await queryInterface.removeColumn('CandidateParticipations', 'reasonForNomination');
      }
      
      if (tableInfo.nominatedBy) {
        await queryInterface.removeColumn('CandidateParticipations', 'nominatedBy');
      }
      
      if (tableInfo.nominatedAt) {
        await queryInterface.removeColumn('CandidateParticipations', 'nominatedAt');
      }
      
      console.log('Rollback completed successfully');
    } catch (error) {
      console.error('Rollback failed:', error.message);
      throw error;
    }
  }
};
