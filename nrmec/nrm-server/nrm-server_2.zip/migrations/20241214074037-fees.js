// migrations/20241223HHMMSS-update-fees.js
'use strict';

const feeStructure = require('../config/Fee_Json.json');

function createUpdatedFeeRecords(electionType, subTypeObj, queryInterface) {
  const records = [];

  for (const [subType, value] of Object.entries(subTypeObj)) {
    if (typeof value === 'object' && value !== null) {
      if (subType === 'partyStructure') {
        // Handle party structure fees with additional validation
        for (const [category, positions] of Object.entries(value)) {
          for (const [position, amount] of Object.entries(positions)) {
            records.push({
              electionType,
              subType,
              category,
              position,
              amount: validateAmount(amount),
              isActive: true,
              createdAt: new Date(),
              updatedAt: new Date(),
              version: 2, // Add version tracking
              lastModified: new Date()
            });
          }
        }
      } else if (typeof value === 'object') {
        // Handle other nested structures with enhanced error handling
        for (const [position, amount] of Object.entries(value)) {
          records.push({
            electionType,
            subType,
            position,
            amount: validateAmount(amount),
            isActive: true,
            createdAt: new Date(),
            updatedAt: new Date(),
            version: 2,
            lastModified: new Date()
          });
        }
      }
    } else {
      // Handle flat fee structure with validation
      records.push({
        electionType,
        subType,
        amount: validateAmount(value),
        isActive: true,
        createdAt: new Date(),
        updatedAt: new Date(),
        version: 2,
        lastModified: new Date()
      });
    }
  }

  return records;
}

function validateAmount(amount) {
  const parsedAmount = parseFloat(amount);
  if (isNaN(parsedAmount) || parsedAmount < 0) {
    throw new Error(`Invalid fee amount: ${amount}`);
  }
  return parsedAmount;
}

async function backupExistingFees(queryInterface) {
  const existingFees = await queryInterface.sequelize.query(
    'SELECT * FROM Fees',
    { type: queryInterface.sequelize.QueryTypes.SELECT }
  );
  
  if (existingFees.length > 0) {
    await queryInterface.bulkInsert('FeeHistory', existingFees.map(fee => ({
      ...fee,
      originalId: fee.id,
      archivedAt: new Date()
    })));
  }
}

module.exports = {
  up: async (queryInterface, Sequelize) => {
    // Create FeeHistory table if it doesn't exist
    await queryInterface.createTable('FeeHistory', {
      id: {
        allowNull: false,
        autoIncrement: true,
        primaryKey: true,
        type: Sequelize.INTEGER
      },
      originalId: {
        type: Sequelize.INTEGER,
        allowNull: false
      },
      electionType: {
        type: Sequelize.STRING,
        allowNull: false
      },
      subType: {
        type: Sequelize.STRING,
        allowNull: false
      },
      category: {
        type: Sequelize.STRING,
        allowNull: true
      },
      position: {
        type: Sequelize.STRING,
        allowNull: true
      },
      amount: {
        type: Sequelize.DECIMAL(10, 2),
        allowNull: false
      },
      isActive: {
        type: Sequelize.BOOLEAN,
        defaultValue: true
      },
      archivedAt: {
        type: Sequelize.DATE,
        allowNull: false
      },
      createdAt: {
        type: Sequelize.DATE,
        allowNull: false
      },
      updatedAt: {
        type: Sequelize.DATE,
        allowNull: false
      }
    });

    // Add new columns to Fees table if they don't exist
    const tableDesc = await queryInterface.describeTable('Fees');
    
    if (!tableDesc.version) {
      await queryInterface.addColumn('Fees', 'version', {
        type: Sequelize.INTEGER,
        allowNull: false,
        defaultValue: 1
      });
    }

    if (!tableDesc.lastModified) {
      await queryInterface.addColumn('Fees', 'lastModified', {
        type: Sequelize.DATE,
        allowNull: false,
        defaultValue: Sequelize.fn('NOW')
      });
    }

    // Backup existing fees
    await backupExistingFees(queryInterface);

    // Clear existing fees
    await queryInterface.bulkDelete('Fees', null, {});

    // Insert updated fee records
    const feeRecords = [];
    for (const [electionType, subTypes] of Object.entries(feeStructure)) {
      const records = createUpdatedFeeRecords(electionType, subTypes, queryInterface);
      feeRecords.push(...records);
    }

    return queryInterface.bulkInsert('Fees', feeRecords);
  },

  down: async (queryInterface, Sequelize) => {
    // Revert the changes in reverse order
    const lastBackup = await queryInterface.sequelize.query(
      'SELECT * FROM FeeHistory WHERE archivedAt = (SELECT MAX(archivedAt) FROM FeeHistory)',
      { type: queryInterface.sequelize.QueryTypes.SELECT }
    );

    // Restore the backup
    if (lastBackup.length > 0) {
      await queryInterface.bulkDelete('Fees', null, {});
      await queryInterface.bulkInsert('Fees', lastBackup.map(({ id, originalId, archivedAt, ...fee }) => fee));
    }

    // Remove added columns if they exist
    const tableDesc = await queryInterface.describeTable('Fees');
    
    if (tableDesc.version) {
      await queryInterface.removeColumn('Fees', 'version');
    }
    
    if (tableDesc.lastModified) {
      await queryInterface.removeColumn('Fees', 'lastModified');
    }

    // Drop the FeeHistory table
    return queryInterface.dropTable('FeeHistory');
  }
};