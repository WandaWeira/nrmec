const bcrypt = require("bcryptjs");

module.exports = {
  up: async (queryInterface, Sequelize) => {
    const hashedPassword = await bcrypt.hash("FINAcle2000//", 10);

    return queryInterface.bulkInsert("Users", [
      {
        firstName: "Gidi",
        lastName: "Sadara",
        email: "gidis@nrmec.co.ug",
        password: hashedPassword,
        ninNumber: "SA123456789",
        phoneNumber: "+256773599715",
        role: "SuperAdmin",
        createdAt: new Date(),
        updatedAt: new Date(),
      },
    ]);
  },

  down: (queryInterface, Sequelize) => {
    return queryInterface.bulkDelete(
      "Users",
      { email: "scarletweira@gmail.com" },
      {}
    );
  },
};

// npx sequelize-cli db:seed:all
// npx sequelize-cli db:migrate

// docker compose up -d
// docker exec -it node-backend npm run db:seed
// docker exec -it node-backend npm run db:migrate

