'use strict';

/** @type {import('sequelize-cli').Migration} */
module.exports = {
  async up (queryInterface, Sequelize) {
    await queryInterface.createTable('Votes', {
      id: {
        allowNull: false,
        autoIncrement: true,
        primaryKey: true,
        type: Sequelize.INTEGER
      },
      candidateParticipationId: {
        type: Sequelize.INTEGER,
        allowNull: false,
        references: {
          model: 'CandidateParticipations',
          key: 'id'
        },
        onUpdate: 'CASCADE',
        onDelete: 'CASCADE'
      },
      votes: {
        type: Sequelize.INTEGER,
        allowNull: false,
        defaultValue: 0,
        validate: {
          min: 0
        }
      },
      electionType: {
        type: Sequelize.ENUM('PRIMARIES', 'INTERNAL_PARTY'),
        allowNull: false
      },
      level: {
        type: Sequelize.ENUM('NATIONAL', 'REGIONAL', 'DISTRICT', 'CONSTITUENCY_MUNICIPALITY', 'SUBCOUNTY_DIVISION', 'PARISH_WARD', 'VILLAGE_CELL'),
        allowNull: false
      },
      positionPath: {
        type: Sequelize.STRING,
        allowNull: true
      },
      regionId: {
        type: Sequelize.INTEGER,
        allowNull: true,
        references: {
          model: 'Regions',
          key: 'id'
        },
        onUpdate: 'CASCADE',
        onDelete: 'SET NULL'
      },
      subregionId: {
        type: Sequelize.INTEGER,
        allowNull: true,
        references: {
          model: 'Subregions',
          key: 'id'
        },
        onUpdate: 'CASCADE',
        onDelete: 'SET NULL'
      },
      districtId: {
        type: Sequelize.INTEGER,
        allowNull: true,
        references: {
          model: 'Districts',
          key: 'id'
        },
        onUpdate: 'CASCADE',
        onDelete: 'SET NULL'
      },
      constituencyMunicipalityId: {
        type: Sequelize.INTEGER,
        allowNull: true,
        references: {
          model: 'ConstituencyMunicipalities',
          key: 'id'
        },
        onUpdate: 'CASCADE',
        onDelete: 'SET NULL'
      },
      subcountyDivisionId: {
        type: Sequelize.INTEGER,
        allowNull: true,
        references: {
          model: 'SubcountyDivisions',
          key: 'id'
        },
        onUpdate: 'CASCADE',
        onDelete: 'SET NULL'
      },
      parishWardId: {
        type: Sequelize.INTEGER,
        allowNull: true,
        references: {
          model: 'ParishWards',
          key: 'id'
        },
        onUpdate: 'CASCADE',
        onDelete: 'SET NULL'
      },
      villageCellId: {
        type: Sequelize.INTEGER,
        allowNull: true,
        references: {
          model: 'VillageCells',
          key: 'id'
        },
        onUpdate: 'CASCADE',
        onDelete: 'SET NULL'
      },
      recordedBy: {
        type: Sequelize.INTEGER,
        allowNull: true,
        references: {
          model: 'Users',
          key: 'id'
        },
        onUpdate: 'CASCADE',
        onDelete: 'SET NULL'
      },
      updatedBy: {
        type: Sequelize.INTEGER,
        allowNull: true,
        references: {
          model: 'Users',
          key: 'id'
        },
        onUpdate: 'CASCADE',
        onDelete: 'SET NULL'
      },
      notes: {
        type: Sequelize.TEXT,
        allowNull: true
      },
      createdAt: {
        allowNull: false,
        type: Sequelize.DATE,
        defaultValue: Sequelize.literal('CURRENT_TIMESTAMP')
      },
      updatedAt: {
        allowNull: false,
        type: Sequelize.DATE,
        defaultValue: Sequelize.literal('CURRENT_TIMESTAMP')
      }
    });

    // Add indexes for better query performance
    await queryInterface.addIndex('Votes', ['candidateParticipationId']);
    await queryInterface.addIndex('Votes', ['electionType', 'level']);
    await queryInterface.addIndex('Votes', ['positionPath']);
    await queryInterface.addIndex('Votes', ['regionId']);
    await queryInterface.addIndex('Votes', ['districtId']);
    await queryInterface.addIndex('Votes', ['constituencyMunicipalityId']);
    await queryInterface.addIndex('Votes', ['subcountyDivisionId']);
    await queryInterface.addIndex('Votes', ['parishWardId']);
    await queryInterface.addIndex('Votes', ['villageCellId']);
  },

  async down (queryInterface, Sequelize) {
    await queryInterface.dropTable('Votes');
  }
};
