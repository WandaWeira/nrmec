// Seeder for INTERNAL_PARTY DISTRICT candidates
'use strict';

const { faker } = require('@faker-js/faker');

module.exports = {
  up: async (queryInterface, Sequelize) => {
    // Helper to generate a random integer in a range
    const rand = (min, max) => Math.floor(Math.random() * (max - min + 1)) + min;
    const candidateRows = [];
    const participationRows = [];
    const usedNINs = new Set();
    const year = new Date().getFullYear();

    // Fetch all regions
    const [regions] = await queryInterface.sequelize.query('SELECT id FROM Regions');
    
    if (!regions || regions.length === 0) {
      throw new Error('No regions found in the database. Please seed the regions table first.');
    }

    console.log(`Found ${regions.length} regions`);

    for (let i = 0; i < 500; i++) {
      try {
        // Generate unique NIN
        let nin;
        do {
          nin = 'CF' + faker.number.int({ min: 100000000, max: 999999999 });
        } while (usedNINs.has(nin));
        usedNINs.add(nin);

        // Select a random region
        const region = regions[rand(0, regions.length - 1)];
        
        // Get subregions for this region
        const [subregions] = await queryInterface.sequelize.query(
          'SELECT id FROM Subregions WHERE regionId = ?',
          { replacements: [region.id] }
        );

        if (!subregions || subregions.length === 0) {
          console.log(`No subregions found for region ${region.id}, skipping this iteration`);
          continue;
        }

        const subregion = subregions[rand(0, subregions.length - 1)];

        // Get districts for this subregion
        const [districts] = await queryInterface.sequelize.query(
          'SELECT id FROM Districts WHERE subregionId = ?',
          { replacements: [subregion.id] }
        );

        if (!districts || districts.length === 0) {
          console.log(`No districts found for subregion ${subregion.id}, skipping this iteration`);
          continue;
        }

        const district = districts[rand(0, districts.length - 1)];

        // Get constituencies/municipalities for this district
        const [constituencies] = await queryInterface.sequelize.query(
          'SELECT id FROM ConstituencyMunicipalities WHERE districtId = ?',
          { replacements: [district.id] }
        );

        if (!constituencies || constituencies.length === 0) {
          console.log(`No constituencies found for district ${district.id}, skipping this iteration`);
          continue;
        }

        const constituency = constituencies[rand(0, constituencies.length - 1)];

        // Get subcounties/divisions for this constituency
        const [subcounties] = await queryInterface.sequelize.query(
          'SELECT id FROM SubcountiesDivisions WHERE constituencyMunicipalityId = ?',
          { replacements: [constituency.id] }
        );

        if (!subcounties || subcounties.length === 0) {
          console.log(`No subcounties found for constituency ${constituency.id}, skipping this iteration`);
          continue;
        }

        const subcounty = subcounties[rand(0, subcounties.length - 1)];

        // Get parish/wards for this subcounty
        const [parishes] = await queryInterface.sequelize.query(
          'SELECT id FROM ParishWards WHERE subcountyDivisionId = ?',
          { replacements: [subcounty.id] }
        );

        if (!parishes || parishes.length === 0) {
          console.log(`No parishes found for subcounty ${subcounty.id}, skipping this iteration`);
          continue;
        }

        const parish = parishes[rand(0, parishes.length - 1)];

        // Get village cells for this parish
        const [villages] = await queryInterface.sequelize.query(
          'SELECT id FROM VillageCells WHERE parishWardId = ?',
          { replacements: [parish.id] }
        );

        if (!villages || villages.length === 0) {
          console.log(`No villages found for parish ${parish.id}, skipping this iteration`);
          continue;
        }

        const village = villages[rand(0, villages.length - 1)];

        const firstName = faker.name.firstName();
        const lastName = faker.name.lastName();
        const phoneNumber = '+2567' + faker.number.int({ min: 1000000, max: 9999999 });
        const gender = faker.helpers.arrayElement(['Male', 'Female']);
        const category = faker.helpers.arrayElement(['YOUTH', 'WOMEN', 'PWD', 'ELDERLY', 'MAIN']);
        const position = faker.helpers.arrayElement(['CHAIRPERSON', 'VICE_CHAIRPERSON', 'SECRETARY', 'TREASURER']);
        const positionPath = `INTERNAL_PARTY.DISTRICT.${category}.${position}`;

        candidateRows.push({
          firstName,
          lastName,
          ninNumber: nin,
          phoneNumber,
          electionType: 'INTERNAL_PARTY',
          gender,
          createdAt: new Date(),
          updatedAt: new Date(),
        });

        // Store the administrative unit IDs for later use
        candidateRows[candidateRows.length - 1].adminUnits = {
          regionId: region.id,
          subregionId: subregion.id,
          districtId: district.id,
          constituencyMunicipalityId: constituency.id,
          subcountyDivisionId: subcounty.id,
          parishWardId: parish.id,
          villageCellId: village.id
        };

      } catch (error) {
        console.error(`Error processing candidate ${i}:`, error);
        continue;
      }
    }

    if (candidateRows.length === 0) {
      throw new Error('No valid candidates could be created. Please check if all required administrative units exist in the database.');
    }

    console.log(`Created ${candidateRows.length} candidate records`);

    // Insert candidates and get their IDs
    const insertedCandidates = await queryInterface.bulkInsert('Candidates', candidateRows.map(({ adminUnits, ...rest }) => rest), { returning: true });
    
    // If returning is not supported, fetch the last candidates
    let candidateIds;
    if (Array.isArray(insertedCandidates) && insertedCandidates.length === candidateRows.length) {
      candidateIds = insertedCandidates.map(c => c.id);
    } else {
      // fallback: fetch last candidates
      const [results] = await queryInterface.sequelize.query(
        `SELECT id FROM Candidates ORDER BY id DESC LIMIT ${candidateRows.length}`
      );
      candidateIds = results.map(r => r.id).reverse();
    }

    // Create participation records
    for (let i = 0; i < candidateRows.length; i++) {
      const { adminUnits } = candidateRows[i];
      const category = faker.helpers.arrayElement(['YOUTH', 'WOMEN', 'PWD', 'ELDERLY', 'MAIN']);
      const position = faker.helpers.arrayElement(['CHAIRPERSON', 'VICE_CHAIRPERSON', 'SECRETARY', 'TREASURER']);
      const positionPath = `INTERNAL_PARTY.DISTRICT.${category}.${position}`;

      participationRows.push({
        candidateId: candidateIds[i],
        electionType: 'INTERNAL_PARTY',
        level: 'DISTRICT',
        positionPath,
        regionId: adminUnits.regionId,
        subregionId: adminUnits.subregionId,
        districtId: adminUnits.districtId,
        constituencyMunicipalityId: adminUnits.constituencyMunicipalityId,
        subcountyDivisionId: adminUnits.subcountyDivisionId,
        parishWardId: adminUnits.parishWardId,
        villageCellId: adminUnits.villageCellId,
        year,
        status: 'pending',
        isQualified: faker.datatype.boolean(),
        vote: faker.number.int({ min: 0, max: 1000 }),
        createdAt: new Date(),
        updatedAt: new Date(),
      });
    }

    console.log(`Creating ${participationRows.length} participation records`);
    await queryInterface.bulkInsert('CandidateParticipations', participationRows);
    console.log('Seeder completed successfully');
  },

  down: async (queryInterface, Sequelize) => {
    // Remove only the seeded candidates and participations
    await queryInterface.bulkDelete('CandidateParticipations', { level: 'DISTRICT', electionType: 'INTERNAL_PARTY' });
    await queryInterface.bulkDelete('Candidates', { electionType: 'INTERNAL_PARTY' });
  }
}; 