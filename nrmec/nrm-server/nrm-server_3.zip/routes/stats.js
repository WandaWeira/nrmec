const express = require("express");
const router = express.Router();
const {
  Region,
  Subregion,
  ConstituencyMunicipality,
  SubcountyDivision,
  ParishWard,
  VillageCell,
  District,
} = require("../models");
const { authMiddleware, checkPermission } = require("../middleware/middleware");
const { sequelize } = require("../models");

router.get(
  "/administrative-units",
  authMiddleware,
  checkPermission("PEO"),
  async (req, res) => {
    try {
      const stats = {
        regions: await Region.count(),
        subregions: await Subregion.count(),
        constituenciesMunicipalities: await ConstituencyMunicipality.count(),
        subcountiesDivisions: await SubcountyDivision.count(),
        parishesWards: await ParishWard.count(),
        villagesCells: await VillageCell.count(),
        districts: await District.count(),
      };

      res.json(stats);
    } catch (error) {
      res.status(500).json({ message: error.message });
    }
  }
);

router.get("/dashboard", async (req, res) => {
  try {
    // First, let's check if we can get basic counts
    const districtsCount = await District.count();

    // Get districts per region with simpler query first
    const districtsPerRegion = await Region.findAll({
      include: [
        {
          model: Subregion,
          as: "subregions",
          include: [
            {
              model: District,
              as: "districts",
            },
          ],
        },
      ],
      raw: false,
    });

    // Transform the data
    const formattedDistrictsPerRegion = districtsPerRegion.map((region) => ({
      name: region.name,
      districtCount: region.subregions.reduce(
        (acc, subregion) => acc + subregion.districts.length,
        0
      ),
    }));

    // Get counts for administrative units
    const adminUnitsDistribution = {
      Districts: await District.count(),
      Constituencies: await ConstituencyMunicipality.count(),
      Subcounties: await SubcountyDivision.count(),
      Parishes: await ParishWard.count(),
      Villages: await VillageCell.count(),
    };

    // Get subregions with all their nested data
    const subregionsData = await Subregion.findAll({
      include: [
        {
          model: District,
          as: "districts",
          include: [
            {
              model: ConstituencyMunicipality,
              as: "constituenciesMunicipalities",
              include: [
                {
                  model: SubcountyDivision,
                  as: "subcountiesDivisions",
                  include: [
                    {
                      model: ParishWard,
                      as: "parishesWards",
                      include: [
                        {
                          model: VillageCell,
                          as: "villagesCells",
                        },
                      ],
                    },
                  ],
                },
              ],
            },
          ],
        },
      ],
    });

    // Transform the data to match the chart format
    const statsPerSubregion = subregionsData.map((subregion) => ({
      subregionName: subregion.name,
      districtCount: subregion.districts.length,
      constituencyCount: subregion.districts.reduce(
        (acc, district) => acc + district.constituenciesMunicipalities.length,
        0
      ),
      subcountyCount: subregion.districts.reduce(
        (acc, district) =>
          acc +
          district.constituenciesMunicipalities.reduce(
            (acc2, constituency) =>
              acc2 + constituency.subcountiesDivisions.length,
            0
          ),
        0
      ),
      parishCount: subregion.districts.reduce(
        (acc, district) =>
          acc +
          district.constituenciesMunicipalities.reduce(
            (acc2, constituency) =>
              acc2 +
              constituency.subcountiesDivisions.reduce(
                (acc3, subcounty) => acc3 + subcounty.parishesWards.length,
                0
              ),
            0
          ),
        0
      ),
      villageCount: subregion.districts.reduce(
        (acc, district) =>
          acc +
          district.constituenciesMunicipalities.reduce(
            (acc2, constituency) =>
              acc2 +
              constituency.subcountiesDivisions.reduce(
                (acc3, subcounty) =>
                  acc3 +
                  subcounty.parishesWards.reduce(
                    (acc4, parish) => acc4 + parish.villagesCells.length,
                    0
                  ),
                0
              ),
            0
          ),
        0
      ),
    }));

    res.json({
      districtsPerRegion: formattedDistrictsPerRegion,
      adminUnitsDistribution,
      statsPerSubregion, // This matches the chart data structure
    });
  } catch (error) {
    console.error("Detailed error:", {
      message: error.message,
      stack: error.stack,
      name: error.name,
    });
    res.status(500).json({
      message: "Error fetching dashboard statistics",
      error: error.message,
    });
  }
});

module.exports = router;
